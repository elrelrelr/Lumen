import { a as __toCommonJS, i as __require, n as __esmMin, r as __exportAll, t as __commonJSMin } from "./rolldown-runtime-D1cXj70v.js";
//#region node_modules/regenerator-runtime/runtime.js
var require_runtime = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* Copyright (c) 2014-present, Facebook, Inc.
	*
	* This source code is licensed under the MIT license found in the
	* LICENSE file in the root directory of this source tree.
	*/
	var runtime = function(exports$1) {
		"use strict";
		var Op = Object.prototype;
		var hasOwn = Op.hasOwnProperty;
		var defineProperty = Object.defineProperty || function(obj, key, desc) {
			obj[key] = desc.value;
		};
		var undefined;
		var $Symbol = typeof Symbol === "function" ? Symbol : {};
		var iteratorSymbol = $Symbol.iterator || "@@iterator";
		var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
		var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
		function define(obj, key, value) {
			Object.defineProperty(obj, key, {
				value,
				enumerable: true,
				configurable: true,
				writable: true
			});
			return obj[key];
		}
		try {
			define({}, "");
		} catch (err) {
			define = function(obj, key, value) {
				return obj[key] = value;
			};
		}
		function wrap(innerFn, outerFn, self, tryLocsList) {
			var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
			var generator = Object.create(protoGenerator.prototype);
			defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, new Context(tryLocsList || [])) });
			return generator;
		}
		exports$1.wrap = wrap;
		function tryCatch(fn, obj, arg) {
			try {
				return {
					type: "normal",
					arg: fn.call(obj, arg)
				};
			} catch (err) {
				return {
					type: "throw",
					arg: err
				};
			}
		}
		var GenStateSuspendedStart = "suspendedStart";
		var GenStateSuspendedYield = "suspendedYield";
		var GenStateExecuting = "executing";
		var GenStateCompleted = "completed";
		var ContinueSentinel = {};
		function Generator() {}
		function GeneratorFunction() {}
		function GeneratorFunctionPrototype() {}
		var IteratorPrototype = {};
		define(IteratorPrototype, iteratorSymbol, function() {
			return this;
		});
		var getProto = Object.getPrototypeOf;
		var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
		if (NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) IteratorPrototype = NativeIteratorPrototype;
		var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
		GeneratorFunction.prototype = GeneratorFunctionPrototype;
		defineProperty(Gp, "constructor", {
			value: GeneratorFunctionPrototype,
			configurable: true
		});
		defineProperty(GeneratorFunctionPrototype, "constructor", {
			value: GeneratorFunction,
			configurable: true
		});
		GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction");
		function defineIteratorMethods(prototype) {
			[
				"next",
				"throw",
				"return"
			].forEach(function(method) {
				define(prototype, method, function(arg) {
					return this._invoke(method, arg);
				});
			});
		}
		exports$1.isGeneratorFunction = function(genFun) {
			var ctor = typeof genFun === "function" && genFun.constructor;
			return ctor ? ctor === GeneratorFunction || (ctor.displayName || ctor.name) === "GeneratorFunction" : false;
		};
		exports$1.mark = function(genFun) {
			if (Object.setPrototypeOf) Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
			else {
				genFun.__proto__ = GeneratorFunctionPrototype;
				define(genFun, toStringTagSymbol, "GeneratorFunction");
			}
			genFun.prototype = Object.create(Gp);
			return genFun;
		};
		exports$1.awrap = function(arg) {
			return { __await: arg };
		};
		function AsyncIterator(generator, PromiseImpl) {
			function invoke(method, arg, resolve, reject) {
				var record = tryCatch(generator[method], generator, arg);
				if (record.type === "throw") reject(record.arg);
				else {
					var result = record.arg;
					var value = result.value;
					if (value && typeof value === "object" && hasOwn.call(value, "__await")) return PromiseImpl.resolve(value.__await).then(function(value) {
						invoke("next", value, resolve, reject);
					}, function(err) {
						invoke("throw", err, resolve, reject);
					});
					return PromiseImpl.resolve(value).then(function(unwrapped) {
						result.value = unwrapped;
						resolve(result);
					}, function(error) {
						return invoke("throw", error, resolve, reject);
					});
				}
			}
			var previousPromise;
			function enqueue(method, arg) {
				function callInvokeWithMethodAndArg() {
					return new PromiseImpl(function(resolve, reject) {
						invoke(method, arg, resolve, reject);
					});
				}
				return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
			}
			defineProperty(this, "_invoke", { value: enqueue });
		}
		defineIteratorMethods(AsyncIterator.prototype);
		define(AsyncIterator.prototype, asyncIteratorSymbol, function() {
			return this;
		});
		exports$1.AsyncIterator = AsyncIterator;
		exports$1.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
			if (PromiseImpl === void 0) PromiseImpl = Promise;
			var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
			return exports$1.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result) {
				return result.done ? result.value : iter.next();
			});
		};
		function makeInvokeMethod(innerFn, self, context) {
			var state = GenStateSuspendedStart;
			return function invoke(method, arg) {
				if (state === GenStateExecuting) throw new Error("Generator is already running");
				if (state === GenStateCompleted) {
					if (method === "throw") throw arg;
					return doneResult();
				}
				context.method = method;
				context.arg = arg;
				while (true) {
					var delegate = context.delegate;
					if (delegate) {
						var delegateResult = maybeInvokeDelegate(delegate, context);
						if (delegateResult) {
							if (delegateResult === ContinueSentinel) continue;
							return delegateResult;
						}
					}
					if (context.method === "next") context.sent = context._sent = context.arg;
					else if (context.method === "throw") {
						if (state === GenStateSuspendedStart) {
							state = GenStateCompleted;
							throw context.arg;
						}
						context.dispatchException(context.arg);
					} else if (context.method === "return") context.abrupt("return", context.arg);
					state = GenStateExecuting;
					var record = tryCatch(innerFn, self, context);
					if (record.type === "normal") {
						state = context.done ? GenStateCompleted : GenStateSuspendedYield;
						if (record.arg === ContinueSentinel) continue;
						return {
							value: record.arg,
							done: context.done
						};
					} else if (record.type === "throw") {
						state = GenStateCompleted;
						context.method = "throw";
						context.arg = record.arg;
					}
				}
			};
		}
		function maybeInvokeDelegate(delegate, context) {
			var methodName = context.method;
			var method = delegate.iterator[methodName];
			if (method === undefined) {
				context.delegate = null;
				if (methodName === "throw" && delegate.iterator["return"]) {
					context.method = "return";
					context.arg = undefined;
					maybeInvokeDelegate(delegate, context);
					if (context.method === "throw") return ContinueSentinel;
				}
				if (methodName !== "return") {
					context.method = "throw";
					context.arg = /* @__PURE__ */ new TypeError("The iterator does not provide a '" + methodName + "' method");
				}
				return ContinueSentinel;
			}
			var record = tryCatch(method, delegate.iterator, context.arg);
			if (record.type === "throw") {
				context.method = "throw";
				context.arg = record.arg;
				context.delegate = null;
				return ContinueSentinel;
			}
			var info = record.arg;
			if (!info) {
				context.method = "throw";
				context.arg = /* @__PURE__ */ new TypeError("iterator result is not an object");
				context.delegate = null;
				return ContinueSentinel;
			}
			if (info.done) {
				context[delegate.resultName] = info.value;
				context.next = delegate.nextLoc;
				if (context.method !== "return") {
					context.method = "next";
					context.arg = undefined;
				}
			} else return info;
			context.delegate = null;
			return ContinueSentinel;
		}
		defineIteratorMethods(Gp);
		define(Gp, toStringTagSymbol, "Generator");
		define(Gp, iteratorSymbol, function() {
			return this;
		});
		define(Gp, "toString", function() {
			return "[object Generator]";
		});
		function pushTryEntry(locs) {
			var entry = { tryLoc: locs[0] };
			if (1 in locs) entry.catchLoc = locs[1];
			if (2 in locs) {
				entry.finallyLoc = locs[2];
				entry.afterLoc = locs[3];
			}
			this.tryEntries.push(entry);
		}
		function resetTryEntry(entry) {
			var record = entry.completion || {};
			record.type = "normal";
			delete record.arg;
			entry.completion = record;
		}
		function Context(tryLocsList) {
			this.tryEntries = [{ tryLoc: "root" }];
			tryLocsList.forEach(pushTryEntry, this);
			this.reset(true);
		}
		exports$1.keys = function(val) {
			var object = Object(val);
			var keys = [];
			for (var key in object) keys.push(key);
			keys.reverse();
			return function next() {
				while (keys.length) {
					var key = keys.pop();
					if (key in object) {
						next.value = key;
						next.done = false;
						return next;
					}
				}
				next.done = true;
				return next;
			};
		};
		function values(iterable) {
			if (iterable) {
				var iteratorMethod = iterable[iteratorSymbol];
				if (iteratorMethod) return iteratorMethod.call(iterable);
				if (typeof iterable.next === "function") return iterable;
				if (!isNaN(iterable.length)) {
					var i = -1, next = function next() {
						while (++i < iterable.length) if (hasOwn.call(iterable, i)) {
							next.value = iterable[i];
							next.done = false;
							return next;
						}
						next.value = undefined;
						next.done = true;
						return next;
					};
					return next.next = next;
				}
			}
			return { next: doneResult };
		}
		exports$1.values = values;
		function doneResult() {
			return {
				value: undefined,
				done: true
			};
		}
		Context.prototype = {
			constructor: Context,
			reset: function(skipTempReset) {
				this.prev = 0;
				this.next = 0;
				this.sent = this._sent = undefined;
				this.done = false;
				this.delegate = null;
				this.method = "next";
				this.arg = undefined;
				this.tryEntries.forEach(resetTryEntry);
				if (!skipTempReset) {
					for (var name in this) if (name.charAt(0) === "t" && hasOwn.call(this, name) && !isNaN(+name.slice(1))) this[name] = undefined;
				}
			},
			stop: function() {
				this.done = true;
				var rootRecord = this.tryEntries[0].completion;
				if (rootRecord.type === "throw") throw rootRecord.arg;
				return this.rval;
			},
			dispatchException: function(exception) {
				if (this.done) throw exception;
				var context = this;
				function handle(loc, caught) {
					record.type = "throw";
					record.arg = exception;
					context.next = loc;
					if (caught) {
						context.method = "next";
						context.arg = undefined;
					}
					return !!caught;
				}
				for (var i = this.tryEntries.length - 1; i >= 0; --i) {
					var entry = this.tryEntries[i];
					var record = entry.completion;
					if (entry.tryLoc === "root") return handle("end");
					if (entry.tryLoc <= this.prev) {
						var hasCatch = hasOwn.call(entry, "catchLoc");
						var hasFinally = hasOwn.call(entry, "finallyLoc");
						if (hasCatch && hasFinally) {
							if (this.prev < entry.catchLoc) return handle(entry.catchLoc, true);
							else if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
						} else if (hasCatch) {
							if (this.prev < entry.catchLoc) return handle(entry.catchLoc, true);
						} else if (hasFinally) {
							if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
						} else throw new Error("try statement without catch or finally");
					}
				}
			},
			abrupt: function(type, arg) {
				for (var i = this.tryEntries.length - 1; i >= 0; --i) {
					var entry = this.tryEntries[i];
					if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
						var finallyEntry = entry;
						break;
					}
				}
				if (finallyEntry && (type === "break" || type === "continue") && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc) finallyEntry = null;
				var record = finallyEntry ? finallyEntry.completion : {};
				record.type = type;
				record.arg = arg;
				if (finallyEntry) {
					this.method = "next";
					this.next = finallyEntry.finallyLoc;
					return ContinueSentinel;
				}
				return this.complete(record);
			},
			complete: function(record, afterLoc) {
				if (record.type === "throw") throw record.arg;
				if (record.type === "break" || record.type === "continue") this.next = record.arg;
				else if (record.type === "return") {
					this.rval = this.arg = record.arg;
					this.method = "return";
					this.next = "end";
				} else if (record.type === "normal" && afterLoc) this.next = afterLoc;
				return ContinueSentinel;
			},
			finish: function(finallyLoc) {
				for (var i = this.tryEntries.length - 1; i >= 0; --i) {
					var entry = this.tryEntries[i];
					if (entry.finallyLoc === finallyLoc) {
						this.complete(entry.completion, entry.afterLoc);
						resetTryEntry(entry);
						return ContinueSentinel;
					}
				}
			},
			"catch": function(tryLoc) {
				for (var i = this.tryEntries.length - 1; i >= 0; --i) {
					var entry = this.tryEntries[i];
					if (entry.tryLoc === tryLoc) {
						var record = entry.completion;
						if (record.type === "throw") {
							var thrown = record.arg;
							resetTryEntry(entry);
						}
						return thrown;
					}
				}
				throw new Error("illegal catch attempt");
			},
			delegateYield: function(iterable, resultName, nextLoc) {
				this.delegate = {
					iterator: values(iterable),
					resultName,
					nextLoc
				};
				if (this.method === "next") this.arg = undefined;
				return ContinueSentinel;
			}
		};
		return exports$1;
	}(typeof module === "object" ? module.exports : {});
	try {
		regeneratorRuntime = runtime;
	} catch (accidentalStrictMode) {
		if (typeof globalThis === "object") globalThis.regeneratorRuntime = runtime;
		else Function("r", "regeneratorRuntime = r")(runtime);
	}
}));
//#endregion
//#region node_modules/tesseract.js/src/utils/getId.js
var require_getId = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = (prefix, cnt) => `${prefix}-${cnt}-${Math.random().toString(16).slice(3, 8)}`;
}));
//#endregion
//#region node_modules/tesseract.js/src/createJob.js
var require_createJob = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var getId = require_getId();
	var jobCounter = 0;
	module.exports = ({ id: _id, action, payload = {} }) => {
		let id = _id;
		if (typeof id === "undefined") {
			id = getId("Job", jobCounter);
			jobCounter += 1;
		}
		return {
			id,
			action,
			payload
		};
	};
}));
//#endregion
//#region node_modules/tesseract.js/src/utils/log.js
var require_log = /* @__PURE__ */ __commonJSMin(((exports) => {
	var logging = false;
	exports.logging = logging;
	exports.setLogging = (_logging) => {
		logging = _logging;
	};
	exports.log = (...args) => logging ? console.log.apply(exports, args) : null;
}));
//#endregion
//#region node_modules/tesseract.js/src/createScheduler.js
var require_createScheduler = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var createJob = require_createJob();
	var { log } = require_log();
	var getId = require_getId();
	var schedulerCounter = 0;
	module.exports = () => {
		const id = getId("Scheduler", schedulerCounter);
		const workers = {};
		const runningWorkers = {};
		let jobQueue = [];
		schedulerCounter += 1;
		const getQueueLen = () => jobQueue.length;
		const getNumWorkers = () => Object.keys(workers).length;
		const dequeue = () => {
			if (jobQueue.length !== 0) {
				const wIds = Object.keys(workers);
				for (let i = 0; i < wIds.length; i += 1) if (typeof runningWorkers[wIds[i]] === "undefined") {
					jobQueue[0](workers[wIds[i]]);
					break;
				}
			}
		};
		const queue = (action, payload) => new Promise((resolve, reject) => {
			const job = createJob({
				action,
				payload
			});
			jobQueue.push(async (w) => {
				jobQueue.shift();
				runningWorkers[w.id] = job;
				try {
					resolve(await w[action].apply(exports, [...payload, job.id]));
				} catch (err) {
					reject(err);
				} finally {
					delete runningWorkers[w.id];
					dequeue();
				}
			});
			log(`[${id}]: Add ${job.id} to JobQueue`);
			log(`[${id}]: JobQueue length=${jobQueue.length}`);
			dequeue();
		});
		const addWorker = (w) => {
			workers[w.id] = w;
			log(`[${id}]: Add ${w.id}`);
			log(`[${id}]: Number of workers=${getNumWorkers()}`);
			dequeue();
			return w.id;
		};
		const addJob = async (action, ...payload) => {
			if (getNumWorkers() === 0) throw Error(`[${id}]: You need to have at least one worker before adding jobs`);
			return queue(action, payload);
		};
		const terminate = async () => {
			Object.keys(workers).forEach(async (wid) => {
				await workers[wid].terminate();
			});
			jobQueue = [];
		};
		return {
			addWorker,
			addJob,
			terminate,
			getQueueLen,
			getNumWorkers
		};
	};
}));
//#endregion
//#region node_modules/tesseract.js/src/utils/getEnvironment.js
var require_getEnvironment = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = (key) => {
		const env = {};
		if (typeof WorkerGlobalScope !== "undefined") env.type = "webworker";
		else if (typeof document === "object") env.type = "browser";
		else if (typeof process === "object" && typeof __require === "function") env.type = "node";
		if (typeof key === "undefined") return env;
		return env[key];
	};
}));
//#endregion
//#region node_modules/tesseract.js/src/utils/resolvePaths.js
var require_resolvePaths = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var resolveURL = require_getEnvironment()("type") === "browser" ? (s) => new URL(s, window.location.href).href : (s) => s;
	module.exports = (options) => {
		const opts = { ...options };
		[
			"corePath",
			"workerPath",
			"langPath"
		].forEach((key) => {
			if (options[key]) opts[key] = resolveURL(opts[key]);
		});
		return opts;
	};
}));
//#endregion
//#region node_modules/tesseract.js/src/constants/OEM.js
var require_OEM = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = {
		TESSERACT_ONLY: 0,
		LSTM_ONLY: 1,
		TESSERACT_LSTM_COMBINED: 2,
		DEFAULT: 3
	};
}));
//#endregion
//#region node_modules/tesseract.js/package.json
var package_exports = /* @__PURE__ */ __exportAll({
	author: () => "",
	browser: () => browser,
	bugs: () => bugs,
	collective: () => collective,
	contributors: () => contributors,
	default: () => package_default,
	dependencies: () => dependencies,
	description: () => description,
	devDependencies: () => devDependencies,
	homepage: () => homepage,
	jsdelivr: () => jsdelivr,
	license: () => license,
	main: () => main,
	name: () => name,
	overrides: () => overrides,
	repository: () => repository,
	scripts: () => scripts,
	type: () => type,
	types: () => types,
	unpkg: () => unpkg,
	version: () => version
}), name, version, description, main, type, types, unpkg, jsdelivr, scripts, browser, contributors, license, devDependencies, dependencies, overrides, repository, bugs, homepage, collective, package_default;
var init_package = __esmMin((() => {
	name = "tesseract.js";
	version = "7.0.0";
	description = "Pure Javascript Multilingual OCR";
	main = "src/index.js";
	type = "commonjs";
	types = "src/index.d.ts";
	unpkg = "dist/tesseract.min.js";
	jsdelivr = "dist/tesseract.min.js";
	scripts = {
		"start": "node scripts/server.js",
		"build": "rimraf dist && webpack --config scripts/webpack.config.prod.js && rollup -c scripts/rollup.esm.mjs",
		"profile:tesseract": "webpack-bundle-analyzer dist/tesseract-stats.json",
		"profile:worker": "webpack-bundle-analyzer dist/worker-stats.json",
		"prepublishOnly": "npm run build",
		"wait": "rimraf dist && wait-on http://localhost:3000/dist/tesseract.min.js",
		"test": "npm-run-all -p -r start test:all",
		"test:all": "npm-run-all wait test:browser test:node:all",
		"test:browser": "karma start karma.conf.js",
		"test:node": "nyc mocha --exit --bail --require ./scripts/test-helper.mjs",
		"test:node:all": "npm run test:node -- ./tests/*.test.mjs",
		"lint": "eslint src",
		"lint:fix": "eslint --fix src",
		"postinstall": "opencollective-postinstall || true"
	};
	browser = { "./src/worker/node/index.js": "./src/worker/browser/index.js" };
	contributors = ["jeromewu"];
	license = "Apache-2.0";
	devDependencies = {
		"@babel/core": "^7.21.4",
		"@babel/eslint-parser": "^7.21.3",
		"@babel/preset-env": "^7.21.4",
		"@rollup/plugin-commonjs": "^24.1.0",
		"acorn": "^8.8.2",
		"babel-loader": "^9.1.2",
		"buffer": "^6.0.3",
		"cors": "^2.8.5",
		"eslint": "^7.32.0",
		"eslint-config-airbnb-base": "^14.2.1",
		"eslint-plugin-import": "^2.27.5",
		"expect.js": "^0.3.1",
		"express": "^4.18.2",
		"mocha": "^10.2.0",
		"npm-run-all": "^4.1.5",
		"karma": "^6.4.2",
		"karma-chrome-launcher": "^3.2.0",
		"karma-firefox-launcher": "^2.1.2",
		"karma-mocha": "^2.0.1",
		"karma-webpack": "^5.0.0",
		"nyc": "^15.1.0",
		"rimraf": "^5.0.0",
		"rollup": "^3.20.7",
		"wait-on": "^7.0.1",
		"webpack": "^5.79.0",
		"webpack-bundle-analyzer": "^4.8.0",
		"webpack-cli": "^5.0.1",
		"webpack-dev-middleware": "^6.0.2",
		"rollup-plugin-sourcemaps": "^0.6.3"
	};
	dependencies = {
		"bmp-js": "^0.1.0",
		"idb-keyval": "^6.2.0",
		"is-url": "^1.2.4",
		"node-fetch": "^2.6.9",
		"opencollective-postinstall": "^2.0.3",
		"regenerator-runtime": "^0.13.3",
		"tesseract.js-core": "^7.0.0",
		"wasm-feature-detect": "^1.8.0",
		"zlibjs": "^0.3.1"
	};
	overrides = { "@rollup/pluginutils": "^5.0.2" };
	repository = {
		"type": "git",
		"url": "https://github.com/naptha/tesseract.js.git"
	};
	bugs = { "url": "https://github.com/naptha/tesseract.js/issues" };
	homepage = "https://github.com/naptha/tesseract.js";
	collective = {
		"type": "opencollective",
		"url": "https://opencollective.com/tesseractjs"
	};
	package_default = {
		name,
		version,
		description,
		main,
		type,
		types,
		unpkg,
		jsdelivr,
		scripts,
		browser,
		author: "",
		contributors,
		license,
		devDependencies,
		dependencies,
		overrides,
		repository,
		bugs,
		homepage,
		collective
	};
}));
//#endregion
//#region node_modules/tesseract.js/src/constants/defaultOptions.js
var require_defaultOptions$1 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = {
		workerBlobURL: true,
		logger: () => {}
	};
}));
//#endregion
//#region node_modules/tesseract.js/src/worker/browser/defaultOptions.js
var require_defaultOptions = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var version = (init_package(), __toCommonJS(package_exports).default).version;
	module.exports = {
		...require_defaultOptions$1(),
		workerPath: `https://cdn.jsdelivr.net/npm/tesseract.js@v${version}/dist/worker.min.js`
	};
}));
//#endregion
//#region node_modules/tesseract.js/src/worker/browser/spawnWorker.js
var require_spawnWorker = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* spawnWorker
	*
	* @name spawnWorker
	* @function create a new Worker in browser
	* @access public
	*/
	module.exports = ({ workerPath, workerBlobURL }) => {
		let worker;
		if (Blob && URL && workerBlobURL) {
			const blob = new Blob([`importScripts("${workerPath}");`], { type: "application/javascript" });
			worker = new Worker(URL.createObjectURL(blob));
		} else worker = new Worker(workerPath);
		return worker;
	};
}));
//#endregion
//#region node_modules/tesseract.js/src/worker/browser/terminateWorker.js
var require_terminateWorker = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* terminateWorker
	*
	* @name terminateWorker
	* @function terminate worker
	* @access public
	*/
	module.exports = (worker) => {
		worker.terminate();
	};
}));
//#endregion
//#region node_modules/tesseract.js/src/worker/browser/onMessage.js
var require_onMessage = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = (worker, handler) => {
		worker.onmessage = ({ data }) => {
			handler(data);
		};
	};
}));
//#endregion
//#region node_modules/tesseract.js/src/worker/browser/send.js
var require_send = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* send
	*
	* @name send
	* @function send packet to worker and create a job
	* @access public
	*/
	module.exports = async (worker, packet) => {
		worker.postMessage(packet);
	};
}));
//#endregion
//#region node_modules/tesseract.js/src/worker/browser/loadImage.js
var require_loadImage = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* readFromBlobOrFile
	*
	* @name readFromBlobOrFile
	* @function
	* @access private
	*/
	var readFromBlobOrFile = (blob) => new Promise((resolve, reject) => {
		const fileReader = new FileReader();
		fileReader.onload = () => {
			resolve(fileReader.result);
		};
		fileReader.onerror = ({ target: { error: { code } } }) => {
			reject(Error(`File could not be read! Code=${code}`));
		};
		fileReader.readAsArrayBuffer(blob);
	});
	/**
	* loadImage
	*
	* @name loadImage
	* @function load image from different source
	* @access private
	*/
	var loadImage = async (image) => {
		let data = image;
		if (typeof image === "undefined") return "undefined";
		if (typeof image === "string") if (/data:image\/([a-zA-Z]*);base64,([^"]*)/.test(image)) data = atob(image.split(",")[1]).split("").map((c) => c.charCodeAt(0));
		else data = await (await fetch(image)).arrayBuffer();
		else if (typeof HTMLElement !== "undefined" && image instanceof HTMLElement) {
			if (image.tagName === "IMG") data = await loadImage(image.src);
			if (image.tagName === "VIDEO") data = await loadImage(image.poster);
			if (image.tagName === "CANVAS") await new Promise((resolve) => {
				image.toBlob(async (blob) => {
					data = await readFromBlobOrFile(blob);
					resolve();
				});
			});
		} else if (typeof OffscreenCanvas !== "undefined" && image instanceof OffscreenCanvas) data = await readFromBlobOrFile(await image.convertToBlob());
		else if (image instanceof File || image instanceof Blob) data = await readFromBlobOrFile(image);
		return new Uint8Array(data);
	};
	module.exports = loadImage;
}));
//#endregion
//#region node_modules/tesseract.js/src/worker/browser/index.js
var require_browser = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = {
		defaultOptions: require_defaultOptions(),
		spawnWorker: require_spawnWorker(),
		terminateWorker: require_terminateWorker(),
		onMessage: require_onMessage(),
		send: require_send(),
		loadImage: require_loadImage()
	};
}));
//#endregion
//#region node_modules/tesseract.js/src/createWorker.js
var require_createWorker = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var resolvePaths = require_resolvePaths();
	var createJob = require_createJob();
	var { log } = require_log();
	var getId = require_getId();
	var OEM = require_OEM();
	var { defaultOptions, spawnWorker, terminateWorker, onMessage, loadImage, send } = require_browser();
	var workerCounter = 0;
	module.exports = async (langs = "eng", oem = OEM.LSTM_ONLY, _options = {}, config = {}) => {
		const id = getId("Worker", workerCounter);
		const { logger, errorHandler, ...options } = resolvePaths({
			...defaultOptions,
			..._options
		});
		const promises = {};
		const currentLangs = typeof langs === "string" ? langs.split("+") : langs;
		let currentOem = oem;
		let currentConfig = config;
		const lstmOnlyCore = [OEM.DEFAULT, OEM.LSTM_ONLY].includes(oem) && !options.legacyCore;
		let workerResReject;
		let workerResResolve;
		const workerRes = new Promise((resolve, reject) => {
			workerResResolve = resolve;
			workerResReject = reject;
		});
		const workerError = (event) => {
			workerResReject(event.message);
		};
		let worker = spawnWorker(options);
		worker.onerror = workerError;
		workerCounter += 1;
		const startJob = ({ id: jobId, action, payload }) => new Promise((resolve, reject) => {
			log(`[${id}]: Start ${jobId}, action=${action}`);
			const promiseId = `${action}-${jobId}`;
			promises[promiseId] = {
				resolve,
				reject
			};
			send(worker, {
				workerId: id,
				jobId,
				action,
				payload
			});
		});
		const load = () => console.warn("`load` is depreciated and should be removed from code (workers now come pre-loaded)");
		const loadInternal = (jobId) => startJob(createJob({
			id: jobId,
			action: "load",
			payload: { options: {
				lstmOnly: lstmOnlyCore,
				corePath: options.corePath,
				logging: options.logging
			} }
		}));
		const writeText = (path, text, jobId) => startJob(createJob({
			id: jobId,
			action: "FS",
			payload: {
				method: "writeFile",
				args: [path, text]
			}
		}));
		const readText = (path, jobId) => startJob(createJob({
			id: jobId,
			action: "FS",
			payload: {
				method: "readFile",
				args: [path, { encoding: "utf8" }]
			}
		}));
		const removeFile = (path, jobId) => startJob(createJob({
			id: jobId,
			action: "FS",
			payload: {
				method: "unlink",
				args: [path]
			}
		}));
		const FS = (method, args, jobId) => startJob(createJob({
			id: jobId,
			action: "FS",
			payload: {
				method,
				args
			}
		}));
		const loadLanguageInternal = (_langs, jobId) => startJob(createJob({
			id: jobId,
			action: "loadLanguage",
			payload: {
				langs: _langs,
				options: {
					langPath: options.langPath,
					dataPath: options.dataPath,
					cachePath: options.cachePath,
					cacheMethod: options.cacheMethod,
					gzip: options.gzip,
					lstmOnly: [OEM.DEFAULT, OEM.LSTM_ONLY].includes(currentOem) && !options.legacyLang
				}
			}
		}));
		const initializeInternal = (_langs, _oem, _config, jobId) => startJob(createJob({
			id: jobId,
			action: "initialize",
			payload: {
				langs: _langs,
				oem: _oem,
				config: _config
			}
		}));
		const reinitialize = (langs = "eng", oem, config, jobId) => {
			if (lstmOnlyCore && [OEM.TESSERACT_ONLY, OEM.TESSERACT_LSTM_COMBINED].includes(oem)) throw Error("Legacy model requested but code missing.");
			const _oem = oem || currentOem;
			currentOem = _oem;
			const _config = config || currentConfig;
			currentConfig = _config;
			const _langs = (typeof langs === "string" ? langs.split("+") : langs).filter((x) => !currentLangs.includes(x));
			currentLangs.push(..._langs);
			if (_langs.length > 0) return loadLanguageInternal(_langs, jobId).then(() => initializeInternal(langs, _oem, _config, jobId));
			return initializeInternal(langs, _oem, _config, jobId);
		};
		const setParameters = (params = {}, jobId) => startJob(createJob({
			id: jobId,
			action: "setParameters",
			payload: { params }
		}));
		const recognize = async (image, opts = {}, output = { text: true }, jobId) => startJob(createJob({
			id: jobId,
			action: "recognize",
			payload: {
				image: await loadImage(image),
				options: opts,
				output
			}
		}));
		const detect = async (image, jobId) => {
			if (lstmOnlyCore) throw Error("`worker.detect` requires Legacy model, which was not loaded.");
			return startJob(createJob({
				id: jobId,
				action: "detect",
				payload: { image: await loadImage(image) }
			}));
		};
		const terminate = async () => {
			if (worker !== null) {
				terminateWorker(worker);
				worker = null;
			}
			return Promise.resolve();
		};
		onMessage(worker, ({ workerId, jobId, status, action, data }) => {
			const promiseId = `${action}-${jobId}`;
			if (status === "resolve") {
				log(`[${workerId}]: Complete ${jobId}`);
				promises[promiseId].resolve({
					jobId,
					data
				});
				delete promises[promiseId];
			} else if (status === "reject") {
				promises[promiseId].reject(data);
				delete promises[promiseId];
				if (action === "load") workerResReject(data);
				if (errorHandler) errorHandler(data);
				else throw Error(data);
			} else if (status === "progress") logger({
				...data,
				userJobId: jobId
			});
		});
		const resolveObj = {
			id,
			worker,
			load,
			writeText,
			readText,
			removeFile,
			FS,
			reinitialize,
			setParameters,
			recognize,
			detect,
			terminate
		};
		loadInternal().then(() => loadLanguageInternal(langs)).then(() => initializeInternal(langs, oem, config)).then(() => workerResResolve(resolveObj)).catch(() => {});
		return workerRes;
	};
}));
//#endregion
//#region node_modules/tesseract.js/src/Tesseract.js
var require_Tesseract = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var createWorker = require_createWorker();
	var recognize = async (image, langs, options) => {
		const worker = await createWorker(langs, 1, options);
		return worker.recognize(image).finally(async () => {
			await worker.terminate();
		});
	};
	var detect = async (image, options) => {
		const worker = await createWorker("osd", 0, options);
		return worker.detect(image).finally(async () => {
			await worker.terminate();
		});
	};
	module.exports = {
		recognize,
		detect
	};
}));
//#endregion
//#region node_modules/tesseract.js/src/constants/languages.js
var require_languages = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* @typedef {object} Languages
	* @property {string} AFR Afrikaans
	* @property {string} AMH Amharic
	* @property {string} ARA Arabic
	* @property {string} ASM Assamese
	* @property {string} AZE Azerbaijani
	* @property {string} AZE_CYRL Azerbaijani - Cyrillic
	* @property {string} BEL Belarusian
	* @property {string} BEN Bengali
	* @property {string} BOD Tibetan
	* @property {string} BOS Bosnian
	* @property {string} BUL Bulgarian
	* @property {string} CAT Catalan; Valencian
	* @property {string} CEB Cebuano
	* @property {string} CES Czech
	* @property {string} CHI_SIM Chinese - Simplified
	* @property {string} CHI_TRA Chinese - Traditional
	* @property {string} CHR Cherokee
	* @property {string} CYM Welsh
	* @property {string} DAN Danish
	* @property {string} DEU German
	* @property {string} DZO Dzongkha
	* @property {string} ELL Greek, Modern (1453-)
	* @property {string} ENG English
	* @property {string} ENM English, Middle (1100-1500)
	* @property {string} EPO Esperanto
	* @property {string} EST Estonian
	* @property {string} EUS Basque
	* @property {string} FAS Persian
	* @property {string} FIN Finnish
	* @property {string} FRA French
	* @property {string} FRK German Fraktur
	* @property {string} FRM French, Middle (ca. 1400-1600)
	* @property {string} GLE Irish
	* @property {string} GLG Galician
	* @property {string} GRC Greek, Ancient (-1453)
	* @property {string} GUJ Gujarati
	* @property {string} HAT Haitian; Haitian Creole
	* @property {string} HEB Hebrew
	* @property {string} HIN Hindi
	* @property {string} HRV Croatian
	* @property {string} HUN Hungarian
	* @property {string} IKU Inuktitut
	* @property {string} IND Indonesian
	* @property {string} ISL Icelandic
	* @property {string} ITA Italian
	* @property {string} ITA_OLD Italian - Old
	* @property {string} JAV Javanese
	* @property {string} JPN Japanese
	* @property {string} KAN Kannada
	* @property {string} KAT Georgian
	* @property {string} KAT_OLD Georgian - Old
	* @property {string} KAZ Kazakh
	* @property {string} KHM Central Khmer
	* @property {string} KIR Kirghiz; Kyrgyz
	* @property {string} KOR Korean
	* @property {string} KUR Kurdish
	* @property {string} LAO Lao
	* @property {string} LAT Latin
	* @property {string} LAV Latvian
	* @property {string} LIT Lithuanian
	* @property {string} MAL Malayalam
	* @property {string} MAR Marathi
	* @property {string} MKD Macedonian
	* @property {string} MLT Maltese
	* @property {string} MSA Malay
	* @property {string} MYA Burmese
	* @property {string} NEP Nepali
	* @property {string} NLD Dutch; Flemish
	* @property {string} NOR Norwegian
	* @property {string} ORI Oriya
	* @property {string} PAN Panjabi; Punjabi
	* @property {string} POL Polish
	* @property {string} POR Portuguese
	* @property {string} PUS Pushto; Pashto
	* @property {string} RON Romanian; Moldavian; Moldovan
	* @property {string} RUS Russian
	* @property {string} SAN Sanskrit
	* @property {string} SIN Sinhala; Sinhalese
	* @property {string} SLK Slovak
	* @property {string} SLV Slovenian
	* @property {string} SPA Spanish; Castilian
	* @property {string} SPA_OLD Spanish; Castilian - Old
	* @property {string} SQI Albanian
	* @property {string} SRP Serbian
	* @property {string} SRP_LATN Serbian - Latin
	* @property {string} SWA Swahili
	* @property {string} SWE Swedish
	* @property {string} SYR Syriac
	* @property {string} TAM Tamil
	* @property {string} TEL Telugu
	* @property {string} TGK Tajik
	* @property {string} TGL Tagalog
	* @property {string} THA Thai
	* @property {string} TIR Tigrinya
	* @property {string} TUR Turkish
	* @property {string} UIG Uighur; Uyghur
	* @property {string} UKR Ukrainian
	* @property {string} URD Urdu
	* @property {string} UZB Uzbek
	* @property {string} UZB_CYRL Uzbek - Cyrillic
	* @property {string} VIE Vietnamese
	* @property {string} YID Yiddish
	*/
	/**
	* @type {Languages}
	*/
	module.exports = {
		AFR: "afr",
		AMH: "amh",
		ARA: "ara",
		ASM: "asm",
		AZE: "aze",
		AZE_CYRL: "aze_cyrl",
		BEL: "bel",
		BEN: "ben",
		BOD: "bod",
		BOS: "bos",
		BUL: "bul",
		CAT: "cat",
		CEB: "ceb",
		CES: "ces",
		CHI_SIM: "chi_sim",
		CHI_TRA: "chi_tra",
		CHR: "chr",
		CYM: "cym",
		DAN: "dan",
		DEU: "deu",
		DZO: "dzo",
		ELL: "ell",
		ENG: "eng",
		ENM: "enm",
		EPO: "epo",
		EST: "est",
		EUS: "eus",
		FAS: "fas",
		FIN: "fin",
		FRA: "fra",
		FRK: "frk",
		FRM: "frm",
		GLE: "gle",
		GLG: "glg",
		GRC: "grc",
		GUJ: "guj",
		HAT: "hat",
		HEB: "heb",
		HIN: "hin",
		HRV: "hrv",
		HUN: "hun",
		IKU: "iku",
		IND: "ind",
		ISL: "isl",
		ITA: "ita",
		ITA_OLD: "ita_old",
		JAV: "jav",
		JPN: "jpn",
		KAN: "kan",
		KAT: "kat",
		KAT_OLD: "kat_old",
		KAZ: "kaz",
		KHM: "khm",
		KIR: "kir",
		KOR: "kor",
		KUR: "kur",
		LAO: "lao",
		LAT: "lat",
		LAV: "lav",
		LIT: "lit",
		MAL: "mal",
		MAR: "mar",
		MKD: "mkd",
		MLT: "mlt",
		MSA: "msa",
		MYA: "mya",
		NEP: "nep",
		NLD: "nld",
		NOR: "nor",
		ORI: "ori",
		PAN: "pan",
		POL: "pol",
		POR: "por",
		PUS: "pus",
		RON: "ron",
		RUS: "rus",
		SAN: "san",
		SIN: "sin",
		SLK: "slk",
		SLV: "slv",
		SPA: "spa",
		SPA_OLD: "spa_old",
		SQI: "sqi",
		SRP: "srp",
		SRP_LATN: "srp_latn",
		SWA: "swa",
		SWE: "swe",
		SYR: "syr",
		TAM: "tam",
		TEL: "tel",
		TGK: "tgk",
		TGL: "tgl",
		THA: "tha",
		TIR: "tir",
		TUR: "tur",
		UIG: "uig",
		UKR: "ukr",
		URD: "urd",
		UZB: "uzb",
		UZB_CYRL: "uzb_cyrl",
		VIE: "vie",
		YID: "yid"
	};
}));
//#endregion
//#region node_modules/tesseract.js/src/constants/PSM.js
var require_PSM = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = {
		OSD_ONLY: "0",
		AUTO_OSD: "1",
		AUTO_ONLY: "2",
		AUTO: "3",
		SINGLE_COLUMN: "4",
		SINGLE_BLOCK_VERT_TEXT: "5",
		SINGLE_BLOCK: "6",
		SINGLE_LINE: "7",
		SINGLE_WORD: "8",
		CIRCLE_WORD: "9",
		SINGLE_CHAR: "10",
		SPARSE_TEXT: "11",
		SPARSE_TEXT_OSD: "12",
		RAW_LINE: "13"
	};
}));
//#endregion
//#region node_modules/tesseract.js/src/index.js
var require_src = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	*
	* Entry point for tesseract.js, should be the entry when bundling.
	*
	* @fileoverview entry point for tesseract.js
	* @author Kevin Kwok <antimatter15@gmail.com>
	* @author Guillermo Webster <gui@mit.edu>
	* @author Jerome Wu <jeromewus@gmail.com>
	*/
	require_runtime();
	var createScheduler = require_createScheduler();
	var createWorker = require_createWorker();
	var Tesseract = require_Tesseract();
	var languages = require_languages();
	var OEM = require_OEM();
	var PSM = require_PSM();
	var { setLogging } = require_log();
	module.exports = {
		languages,
		OEM,
		PSM,
		createScheduler,
		createWorker,
		setLogging,
		...Tesseract
	};
}));
//#endregion
export { require_src as t };
